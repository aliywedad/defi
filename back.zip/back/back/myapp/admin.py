from django.contrib import admin
from .models import *

# admin.site.register(Utilisateur)

admin.site.register(Critère)
admin.site.register(Jery)
admin.site.register(Etudiant)
admin.site.register(Utilisateur)
admin.site.register(Équipe)
admin.site.register(Inscription)
admin.site.register(Défi)
admin.site.register(Soumission)
admin.site.register(Évaluation)
admin.site.register(Résultat)
admin.site.register(administrater)